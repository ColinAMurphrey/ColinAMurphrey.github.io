
// Please, DO NOT touch these values, unless you know what you're doing, and you're experienced with optifine

#define POM

#define NORMAL_MAP_MAX_ANGLE 1.0
#define POM_MAP_RES 16.0                       //[16.0 32.0 64.0 128.0 256.0 512.0 1024.0 2048.0]
#define POM_DEPTH (1.0/12.0)